package MainTester;

import service.UsersService;
import vo.UsersVO;

public class TestMain {

	public static void main(String[] args) {

//		db done move to socketside.
//		UsersService us = UsersService.getInstance();
//		UsersVO a1 = new UsersVO("epson","printer");
//		UsersVO a2 = new UsersVO("epsons","printers");
//		
//		//addUser works fine
//		System.out.println(us.addUser(a1));
//		System.out.println(us.addUser(a2));
//		//getUser works fine
//		System.out.println(us.getUser("epson"));
//		System.out.println(us.getUser("epsons"));
//		//searchUsers
//		for(String eps: us.searchUsers("eps")){
//		System.out.println(eps);
//		}
//		//deleteUser works
//		System.out.println(us.deleteUser(a1));
//		System.out.println(us.deleteUser(a2));
//		
	}

}